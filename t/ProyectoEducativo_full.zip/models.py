# Models are included in app.py for simplicity. If you want separation, move model classes here and import them into app.py
