from flask import Flask, render_template, request, redirect, url_for, flash, send_file
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os
from fpdf import FPDF

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY','devsecretkey')
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL') or 'sqlite:///' + os.path.join(basedir, 'contabilidad.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Models
class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    telefono = db.Column(db.String(50))
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)

class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(200))
    fecha_pago = db.Column(db.DateTime, default=datetime.utcnow)
    student = db.relationship('Student', backref=db.backref('payments', lazy=True))

# Simple home page
@app.route('/')
def index():
    return render_template('index.html')

# Registration form
@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        nombre = request.form['nombre']
        email = request.form['email']
        telefono = request.form.get('telefono','')
        if not nombre or not email:
            flash('Nombre y email son requeridos', 'danger')
            return redirect(url_for('register'))
        s = Student(nombre=nombre, email=email, telefono=telefono)
        db.session.add(s)
        db.session.commit()
        flash('Registro exitoso. ID: {}'.format(s.id), 'success')
        return redirect(url_for('index'))
    return render_template('register.html')

# Payments page (simulate payment)
@app.route('/pay/<int:student_id>', methods=['GET','POST'])
def pay(student_id):
    student = Student.query.get_or_404(student_id)
    if request.method == 'POST':
        amount = float(request.form['amount'] or 0)
        description = request.form.get('description','Pago de matrícula')
        p = Payment(student_id=student.id, amount=amount, description=description)
        db.session.add(p)
        db.session.commit()
        flash('Pago registrado. Se generará la factura PDF.', 'success')
        return redirect(url_for('invoice', payment_id=p.id))
    return render_template('pay.html', student=student)

# Generate invoice PDF using fpdf
@app.route('/invoice/<int:payment_id>')
def invoice(payment_id):
    p = Payment.query.get_or_404(payment_id)
    s = p.student
    # Build PDF
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt="Factura / Invoice", ln=True, align='C')
    pdf.ln(5)
    pdf.cell(200, 8, txt=f"Factura ID: {p.id}", ln=True)
    pdf.cell(200, 8, txt=f"Fecha: {p.fecha_pago.strftime('%Y-%m-%d %H:%M:%S')}", ln=True)
    pdf.ln(4)
    pdf.cell(200, 8, txt=f"Nombre: {s.nombre}", ln=True)
    pdf.cell(200, 8, txt=f"Email: {s.email}", ln=True)
    pdf.cell(200, 8, txt=f"Teléfono: {s.telefono}", ln=True)
    pdf.ln(6)
    pdf.cell(200, 8, txt=f"Descripción: {p.description}", ln=True)
    pdf.cell(200, 8, txt=f"Valor: ${p.amount:.2f}", ln=True)
    # Save temporary file
    tmp_path = os.path.join(basedir, f'factura_{p.id}.pdf')
    pdf.output(tmp_path)
    return send_file(tmp_path, as_attachment=True, download_name=f'factura_{p.id}.pdf')

# Simple admin area (basic password protection via env variable ADMIN_PASS)
from functools import wraps
from flask import Response

def check_auth(password):
    return password == os.environ.get('ADMIN_PASS','admin123')

def authenticate():
    return Response('No autorizado', 401, {'WWW-Authenticate':'Basic realm="Login Required"'})

def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_auth(auth.password):
            return authenticate()
        return f(*args, **kwargs)
    return decorated

@app.route('/admin')
@requires_auth
def admin():
    students = Student.query.order_by(Student.fecha_registro.desc()).all()
    payments = Payment.query.order_by(Payment.fecha_pago.desc()).all()
    return render_template('admin.html', students=students, payments=payments)

if __name__ == '__main__':
    # Create DB if not exists
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT',5000)), debug=True)
